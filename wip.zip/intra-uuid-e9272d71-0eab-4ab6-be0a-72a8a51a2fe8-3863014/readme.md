# libasm

## Overview
## TODO
- [ ] Export at the end of the work
- [ ] Call functions from a main.c
- [ ] Makefile rules to run asm tests
- [ ] Fix testers

## Ressources
Lessons:
- https://asmtutor.com/
- https://medium.com/@leogaudin/libasm-a-guide-to-get-familiar-with-assembly-in-42-830f619f4c5e
- https://beta.hackndo.com/assembly-basics/
- https://sonictk.github.io/asm_tutorial/
- https://www.unilim.fr/pages_perso/tristan.vaccon/cours_nasm.pdf
Documentations:
- https://www.nasm.us/xdoc/2.16.03/html/nasmdoc0.html
- https://www.bencode.net/blob/nasmcheatsheet.pdf
- https://pacman128.github.io/static/pcasm-book-french.pdf
More about asm: 
- https://gitlab.com/uotiug42/asm/libasm
- https://g3tsyst3m.github.io/shellcoding/assembly/debugging/x64-Assembly-&-Shellcoding-101/