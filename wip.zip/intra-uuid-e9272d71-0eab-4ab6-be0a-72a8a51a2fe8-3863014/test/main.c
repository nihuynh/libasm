#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "libasm.h"

int			main(void)
{

    ft_write(1, "test\n", strlen("test\n"));
    ft_write(1, "Test Test\n", strlen("Test Test\n"));

	// printf("\nft_strlen:\n");
	// printf(" FT: %zu Expected: %zu\n", ft_strlen("test"), strlen("test"));
	// printf(" FT: %zu Expected: %zu\n", ft_strlen("\0test"), strlen("\0test"));
	// printf(" FT: %zu Expected: %zu\n", ft_strlen("te\0st"), strlen("te\0st"));
	// printf(" FT: %zu Expected: %zu\n", ft_strlen(""), strlen(""));
	// printf(" FT: %zu Expected: %zu\n", ft_strlen("\0\0"), strlen("\0\0"));
}
